# M10 — décision des paramètres R1 et comparaison à ML-KEM-1024

16 novembre 2026. Préenregistrement après le protocole M10 du commit
`1105e7f`. Aucun paramètre, domaine ou format Rust n'est modifié par ce
chantier. La décision finale ci-dessous attend les sorties prévues,
y compris toute erreur ou expiration de délai.

## Plan fixé avant acquisition

Exécuter exactement **40 travaux neufs**, soit deux profils, deux jeux
finis d'échantillons, deux modèles de coût et cinq familles. R1 conserve
n=256, k=6, q=7681, CBD(3) ; ML-KEM-1024 a n=256, k=4, q=3329, CBD(2).
Les jeux sont respectivement m=1536/1792 et m=1024/1280. Le second est un
hybride idéal distinct ; les chiffrés comprimés réels ne sont pas déclarés
fournir une ligne MLWE indépendante. Le passage au problème LWE aplati
est un proxy d'estimation, pas une identité d'instances indépendantes.

L'estimateur est épinglé au commit courant vérifié le 16 novembre :
`malb/lattice-estimator@7d59f866655362ea8eab803dbc833710c2bc362a`
(commit du 9 novembre 2026). Les 108 calculs M05 au commit f31b86fe restent
historiques ; ils ne sont pas comptés comme nouvelles évaluations. Chaque
nouvelle paire ne compare que le même jeu, modèle, famille et convention.

Familles : uSVP/GSA ; BDD/GSA ; hybride primal avec MITM explicite,
Babai désactivé et GSA ; dual simple avec cible de solveur0,99 ; dual
hybride MATZOV et son μ interne0,5. Ces succès ne sont pas interchangeables.
Modèles : MATZOV classique et sensibilité de réduction BCSS23 quantique,
en gardant les autres travaux de l'estimateur. Le second n'est pas un
comptage de portes d'une attaque quantique complète.

Temps : 300 secondes murales par travail, quatre processus au plus,
affinités choisies parmi CPU0..5. Tous les 40 travaux sont demandés une
fois, sans remplacement d'une famille ou d'une expiration. Les entrées,
sorties, exceptions, stdout/stderr, durées et versions sont conservés.
Un défaut du contrôleur pourra être corrigé seulement dans une reprise
explicitement reliée, avec les tentatives antérieures préservées.

L'optimisation de chaque famille reste sans plafond RAM, comme son API.
Le champ `mem`, lorsqu'il existe, garde son unité documentée en éléments
modulo q. Sa représentation dense en u16 fournit une sensibilité de
stockage déclarée pour des plafonds de 2^40, 2^60 et 2^80 octets ; elle
ne prouve pas le pic physique total. `N` reste un nombre de vecteurs et
n'est pas rebaptisé RAM. Un optimum hors plafond n'est pas une preuve
d'absence d'autre attaque sous plafond. Aucun coût contraint ne sera
inventé en filtrant simplement l'optimum non contraint.

## Sorties falsifiables et décision

Le bilan annoncera les 20 paires attendues, les sorties manquantes, les
écarts et la plage d'extrapolation de MATZOV au-delà de β=1024. Il ne
réduira pas des contrats différents à un minimum de sécurité globale.
Une inversion défavorable R1/témoin dans un modèle retenu, ou un contrat
manquant, reste visible et bloque toute sélection finale automatique.

Le volet C03 calcule séparément les recherches génériques sur les graines
communes à plusieurs clés, les messages sous une même clé et les messages
liés à des clés différentes. Les bornes exactes ou rationnelles sont
contrôlées sur de petits espaces exhaustifs. Les requêtes quantiques
restent distinctes du coût des prédicats réversibles et de leur stockage.
Le nombre256 décrit ici les espaces graines/messages et la sortie ; une
augmentation du rang n'augmente pas leur entropie.

Le volet correction rattache sans les recalculer les fractions certifiées
run-004 et leur transfert RO aux bruits semés, leur population et leur
quantification. Le seuil C05 historique2^-174,8 est conservé. Le résultat
heuristique publié de ML-KEM-1024 ne devient pas un certificat identique,
et le taux honnête ne traite pas une recherche adaptative d'échecs.

La décision C01–C06 sera soit la conservation motivée de R1 pour le
développement, soit une proposition explicite de profil distinct. Les
obstacles de matrice semée, QROM, primitives concrètes, queues du dual,
mémoire bornée et nouvelles adaptations ne sont pas clos par un tableau
de coûts. Aucun nouveau profil ne sera substitué au moteur à la suite
d'un simple gain de rang ou d'un chiffre Core-SVP.

## Veille primaire consultée

La [documentation du mainteneur de l'estimateur](https://github.com/malb/lattice-estimator)
décrit son caractère heuristique et recommande d'identifier le commit.
[Li–Zheng2026/1048](https://eprint.iacr.org/2026/1048) traite la covariance
des scores ; [Bashiri2026/2565](https://eprint.iacr.org/2026/2565) améliore
des analyses duales prouvables. Leurs gains ne sont pas soustraits aux
coûts du panneau sans traduction de leur modèle.

[Kaiburr, version primaire du3novembre2026](https://www.cryptojedi.org/papers/kaiburr-20261103.pdf),
d'Adhikari, Lyubashevsky et Schwabe, étudie des variantes de rang accru
avec une autre loi de bruit, q=3329 et retrait de la compression du
chiffré. Les auteurs publient [du code](https://github.com/cryptojedi/kaiburr),
des preuves de correction EasyCrypt et des réalisations C/Jasmin.
Cela interdit de présenter l'augmentation du rang comme une nouveauté
suffisante. Ces profils, leurs cibles de correction et leurs conventions
Core-SVP sont distincts de R1 ; les fortes valeurs Core-SVP n'éliminent
pas les limites dues aux primitives symétriques inchangées.

## Résultats et décision

En attente des acquisitions préenregistrées. Aucune nouvelle estimation
ou sélection finale n'est annoncée à ce stade.
