"""Finite M06 ASan/std-rebuilt campaign on the frozen measured candidate.

Four harnesses run sequentially after measurement and root timing barriers.
Coverage and independent Python replay are separate postprocessing steps.
The controller never stops or credits a historical campaign.
"""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tarfile

from run_m04_fuzz_smoke import run_target, TARGETS

ROOT = Path(__file__).resolve().parents[1]


def utc():
    return datetime.now(timezone.utc).isoformat()


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path):
    return json.loads(path.read_text())


def save(path, value):
    with path.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write("\n")


def require(value, message):
    if not value:
        raise ValueError(message)


def inventory(folder):
    return {p.relative_to(folder).as_posix(): sha(p) for p in sorted(folder.rglob("*")) if p.is_file()}


def env_for(target):
    env = dict(os.environ, CARGO_HOME=str(ROOT / ".tools/linux-cargo"), RUSTUP_HOME=str(ROOT / ".tools/linux-rustup"),
               RUSTUP_TOOLCHAIN="1.91.1-x86_64-unknown-linux-gnu", RUSTUP_AUTO_INSTALL="0", RUSTC_BOOTSTRAP="1",
               CARGO_BUILD_JOBS="2", CARGO_TARGET_DIR=str(target),
               ASAN_OPTIONS="detect_leaks=1:strict_string_checks=1:detect_stack_use_after_return=1")
    env.pop("RUSTFLAGS", None)
    env["PATH"] = str(ROOT / ".tools/linux-cargo/bin") + ":/usr/local/bin:/usr/bin:/bin"
    return env


def seed_corpora(out):
    receipts = {}
    for name in TARGETS:
        destination = out / "initial-corpus" / name
        destination.mkdir(parents=True)
        origins = [ROOT / "artifacts/generated/m03-seeds-final" / name,
                   ROOT / "artifacts/generated/m03-long-001" / name / "corpus",
                   ROOT / "artifacts/generated/m04-fuzz-smoke" / name / "corpus"]
        require(origins[0].is_dir(), "public synthetic seeds required")
        origin_counts = {}
        for origin in origins:
            count = 0
            if origin.is_dir():
                for path in sorted(origin.iterdir()):
                    if path.is_file():
                        content = path.read_bytes()
                        copied = destination / hashlib.sha256(content).hexdigest()
                        if not copied.exists():
                            copied.write_bytes(content)
                        count += 1
            origin_counts[origin.relative_to(ROOT).as_posix()] = count
        receipts[name] = {"source_files_read": origin_counts, "distinct_inputs": len(list(destination.iterdir())),
                          "sha256": inventory(destination)}
    return receipts


def prepare_and_run(out, measurements, target, cpu, budget):
    require(sys.platform == "linux" and cpu in os.sched_getaffinity(0), "valid Linux CPU required")
    require(120 <= budget <= 600, "declared finite budget of 120..600 CPU seconds per harness")
    require(not out.exists() and not target.exists(), "new campaign and target directories required")
    for marker in ("MEASUREMENTS_DONE", "ROOT_TIMING_DONE"):
        require((measurements / marker).is_file(), f"wait for {marker} before heavy fuzz build")
    measured = read(measurements / "build.json")["builds"]["candidate"]["source_sha256"]
    require(inventory(measurements / "candidate-source") == measured, "measured candidate changed")
    out.mkdir(parents=True)
    shutil.copytree(measurements / "candidate-source", out / "source")
    oracle = out / "source/oracle/kem_r1_reference.py"
    oracle.parent.mkdir()
    shutil.copyfile(ROOT / "results/engine/r1-001/sources/research/kem_r1_reference.py", oracle)
    for name in ("run_m06_fuzz.py", "replay_m06_fuzz_corpus.py", "run_m04_fuzz_smoke.py"):
        shutil.copyfile(ROOT / "research" / name, out / "source/research" / name)
    source_hashes = inventory(out / "source")
    corpus = seed_corpora(out)
    env = env_for(target)
    cargo = str(ROOT / ".tools/linux-cargo/bin/cargo")
    rustc = str(ROOT / ".tools/linux-cargo/bin/rustc")
    versions = {"rustc": subprocess.check_output([rustc, "-Vv"], env=env, text=True),
                "cargo_fuzz": subprocess.check_output([cargo, "fuzz", "--version"], env=env, text=True)}
    require("release: 1.91.1" in versions["rustc"], "unexpected fuzz compiler")
    command = ["taskset", "-c", str(cpu), cargo, "fuzz", "build", "--fuzz-dir", str(out / "source/fuzz"),
               "--target-dir", str(target), "--build-std"]
    save(out / "config.json", {"started_utc": utc(), "source_sha256": source_hashes, "initial_corpus": corpus,
        "candidate_measurement_build_sha256": sha(measurements / "build.json"), "versions": versions,
        "build_command": command, "CPU_seconds_per_harness": budget, "sequential_CPU": cpu,
        "std_rebuild_requested": True, "ASAN_OPTIONS": env["ASAN_OPTIONS"],
        "measurement_barrier_sha256": {name: sha(measurements / name) for name in ("MEASUREMENTS_DONE", "ROOT_TIMING_DONE")},
        "historical_fuzz_CPU_seconds_credited": 0, "research_vectors_feature_enabled": False})
    lock = out / "source/fuzz/Cargo.lock"
    lock_sha = sha(lock)
    with (out / "build.log").open("xb") as log:
        subprocess.run(command, cwd=out / "source", env=env, stdout=log, stderr=subprocess.STDOUT, check=True)
    require(sha(lock) == lock_sha, "fuzz build changed its frozen lock")
    (out / "bin").mkdir()
    binaries = {}
    for name in TARGETS:
        copied = out / "bin" / name
        shutil.copyfile(target / "x86_64-unknown-linux-gnu/release" / name, copied)
        copied.chmod(0o700)
        binaries[name] = sha(copied)
    rebuilt_std = sorted((target / "x86_64-unknown-linux-gnu/release/deps").glob("libstd-*.rlib"))
    require(rebuilt_std, "rebuilt std rlib is absent")
    save(out / "built.json", {"binary_sha256": binaries,
        "rebuilt_std_rlib_sha256": {p.name: sha(p) for p in rebuilt_std}, "frozen_lock_sha256": lock_sha})
    results = {name: run_target(i, out, env, cpu, budget) for i, name in enumerate(TARGETS)}
    save(out / "fuzz-summary.json", {"finished_utc": utc(), "results": results,
        "total_CPU_seconds": sum(r["CPU_seconds"] for r in results.values()),
        "all_four_budgets_reached": all(r["CPU_seconds"] >= budget for r in results.values()),
        "standard_library_rebuilt": True, "source_line_coverage_measured": False,
        "independent_oracle_replayed": False, "historical_fuzz_time_transferred": False})
    return {"all_four_budgets_reached": True, "postprocessing_still_required": True}


def postprocess(out, target):
    require((out / "fuzz-summary.json").is_file(), "completed finite campaign required")
    env = env_for(target)
    cargo = str(ROOT / ".tools/linux-cargo/bin/cargo")
    rustc = str(ROOT / ".tools/linux-cargo/bin/rustc")
    sysroot = Path(subprocess.check_output([rustc, "--print", "sysroot"], env=env, text=True).strip())
    llvm = sysroot / "lib/rustlib/x86_64-unknown-linux-gnu/bin/llvm-cov"
    coverage = {}
    cpu = read(out / "config.json")["sequential_CPU"]
    for name in TARGETS:
        command = ["taskset", "-c", str(cpu), cargo, "fuzz", "coverage", name, str(out / name / "corpus"),
                   "--fuzz-dir", str(out / "source/fuzz"), "--target-dir", str(target), "--",
                   "-timeout=60", "-rss_limit_mb=2048"]
        with (out / f"{name}-coverage.log").open("xb") as log:
            subprocess.run(command, cwd=out / "source", env=env, stdout=log, stderr=subprocess.STDOUT, check=True)
        profile = out / "source/fuzz/coverage" / name / "coverage.profdata"
        binary = target / "x86_64-unknown-linux-gnu/release" / name
        copied_profile = out / f"{name}-coverage.profdata"
        shutil.copyfile(profile, copied_profile)
        raw = subprocess.check_output([str(llvm), "export", "-summary-only", str(binary), "-instr-profile=" + str(profile)], env=env)
        exported = json.loads(raw)
        save(out / f"{name}-coverage.json", exported)
        coverage[name] = [file for item in exported["data"] for file in item["files"]
                          if "/crates/kem1536/src/" in file["filename"]]
        save(out / f"{name}-coverage-receipt.json", {"command": command, "binary_sha256": sha(binary),
            "profdata_sha256": sha(copied_profile), "LLVM_coverage_is_source_level": True,
            "libFuzzer_edges_are_not_source_line_coverage": True})
    save(out / "coverage-summary.json", coverage)
    # This executable is built from the same immutable production source and
    # exposes only deterministic synthetic fixture requests to the oracle.
    replay_target = target.parent / (target.name + "-replay")
    replay_env = env_for(replay_target)
    replay_env.pop("RUSTC_BOOTSTRAP", None)
    command = [cargo, "build", "--locked", "--offline", "--release", "-p", "kem1536-bench", "--bin", "m03-replay"]
    with (out / "replay-build.log").open("xb") as log:
        subprocess.run(command, cwd=out / "source", env=replay_env, stdout=log, stderr=subprocess.STDOUT, check=True)
    replay_binary = out / "bin/m06-replay"
    shutil.copyfile(replay_target / "release/m03-replay", replay_binary)
    replay_binary.chmod(0o700)
    save(out / "replay-build.json", {"binary_sha256": sha(replay_binary), "build_command": command,
                                   "production_source_sha256": read(out / "config.json")["source_sha256"]})
    def windows(path):
        return subprocess.check_output(["wslpath", "-w", str(path)], text=True).strip()
    command = [str(ROOT / ".tools/research-venv/Scripts/python.exe"),
               windows(out / "source/research/replay_m06_fuzz_corpus.py"), "--campaign", windows(out),
               "--linux-binary", str(replay_binary)]
    with (out / "oracle-replay.log").open("xb") as log:
        subprocess.run(command, stdout=log, stderr=subprocess.STDOUT, check=True)
    save(out / "postprocess.json", {"finished_utc": utc(), "source_coverage_exported": True,
        "independent_python_replay_passed": True, "replay_request_count": read(out / "oracle-replay.json")["distinct_deterministic_requests"],
        "full_security_or_constant_time_claim": False})
    return verify(out, finished=False)


def verify(out, finished=True):
    for name, expected in read(out / "config.json")["source_sha256"].items():
        require(sha(out / "source" / name) == expected, f"frozen M06 input changed: {name}")
    config, summary = read(out / "config.json"), read(out / "fuzz-summary.json")
    require(summary["all_four_budgets_reached"] and not summary["historical_fuzz_time_transferred"], "budget not reached")
    for name, result in summary["results"].items():
        require(result["CPU_seconds"] >= config["CPU_seconds_per_harness"] and not result["defects_observed"], "campaign failed")
        require(not any((out / name / "failures").iterdir()), "fuzz defect is present")
        total = sum(s["resource_usage"]["user_seconds"] + s["resource_usage"]["system_seconds"] for s in result["segments"])
        require(abs(total - result["CPU_seconds"]) < 1e-9, "CPU accounting differs")
    require(read(out / "oracle-replay.json")["all_Rust_Python_outputs_equal"], "oracle replay failed")
    require(set(read(out / "coverage-summary.json")) == set(TARGETS), "source coverage incomplete")
    if finished:
        for name, expected in read(out / "provenance.json")["output_sha256"].items():
            member = (out / name).resolve()
            require(member.is_relative_to(out.resolve()) and sha(member) == expected, f"M06 checksum: {name}")
    return {"total_CPU_seconds": summary["total_CPU_seconds"], "all_four_budgets_reached": True,
            "source_coverage_exported": True, "independent_python_replay_passed": True}


def freeze(out):
    result = verify(out, finished=False)
    archive = ROOT / "results/engine/m06-fuzz-001"
    require(not archive.exists(), "never replace M06 fuzz evidence")
    archive.mkdir(parents=True)
    # Build trees and transient per-input coverage files stay local. Preserve
    # source, instrumented binaries, final inputs, profiles and exported receipts.
    selected = ["source", "bin", "initial-corpus", *TARGETS]
    with tarfile.open(archive / "campaign.tar.gz", "w:gz") as bundle:
        def exclude_transient(member):
            return None if "/fuzz/coverage" in member.name else member
        for name in selected:
            bundle.add(out / name, arcname=name, filter=exclude_transient)
        for path in sorted(out.iterdir()):
            if path.is_file():
                bundle.add(path, arcname=path.name)
    for name in ("config.json", "fuzz-summary.json", "coverage-summary.json", "oracle-replay.json", "postprocess.json"):
        shutil.copyfile(out / name, archive / name)
    save(archive / "provenance.json", {"finished_utc": utc(), "output_sha256": inventory(archive),
        "archive_members_sha256": {name: sha(out / name) for name in ("config.json", "fuzz-summary.json", "coverage-summary.json", "oracle-replay.json", "postprocess.json")},
        "historical_fuzz_CPU_seconds_credited": 0})
    return result


def verify_archive(archive):
    """Check retained bytes and recompute finite budget/coverage accounting."""
    receipt = read(archive / "provenance.json")
    for name, expected in receipt["output_sha256"].items():
        path = (archive / name).resolve()
        require(path.is_relative_to(archive.resolve()) and sha(path) == expected, f"archive checksum: {name}")
    with tarfile.open(archive / "campaign.tar.gz", "r:gz") as bundle:
        members = {m.name: m for m in bundle.getmembers() if m.isfile()}
        require(len(members) == sum(m.isfile() for m in bundle.getmembers()), "duplicate archive member")
        def data(name):
            return bundle.extractfile(members[name]).read()
        for name, expected in receipt["archive_members_sha256"].items():
            require(hashlib.sha256(data(name)).hexdigest() == expected, f"nested receipt differs: {name}")
        config = json.loads(data("config.json"))
        for name, expected in config["source_sha256"].items():
            require(hashlib.sha256(data("source/" + name)).hexdigest() == expected, f"source differs: {name}")
        built = json.loads(data("built.json"))
        for name, expected in built["binary_sha256"].items():
            require(hashlib.sha256(data("bin/" + name)).hexdigest() == expected, f"fuzz binary differs: {name}")
        summary = json.loads(data("fuzz-summary.json"))
        total = 0.0
        for name in TARGETS:
            result = summary["results"][name]
            cpu = sum(s["resource_usage"]["user_seconds"] + s["resource_usage"]["system_seconds"] for s in result["segments"])
            require(abs(cpu - result["CPU_seconds"]) < 1e-9 and cpu >= config["CPU_seconds_per_harness"], "archived CPU budget differs")
            require(all(s["exit_code"] == 0 for s in result["segments"]) and not result["defects_observed"], "archived segment failed")
            require(not any(n.startswith(name + "/failures/") for n in members), "archived fuzz defect exists")
            for s in result["segments"]:
                retained = json.loads(data(f"{name}/segment-{s['segment']:03d}-result.json"))
                require(retained == s, "segment summary differs from raw retained result")
            total += cpu
            coverage = json.loads(data(name + "-coverage.json"))
            require(coverage["type"] == "llvm.coverage.json.export", "not a real LLVM coverage export")
            require(any("/crates/kem1536/src/" in f["filename"] for item in coverage["data"] for f in item["files"]), "engine source absent from coverage")
        require(abs(total - summary["total_CPU_seconds"]) < 1e-9, "total CPU accounting differs")
        oracle = json.loads(data("oracle-replay.json"))
        require(oracle["all_Rust_Python_outputs_equal"] and oracle["distinct_deterministic_requests"] > 0, "oracle evidence absent")
    return {"total_CPU_seconds": total, "source_and_binary_hashes_verified": True,
            "source_coverage_exports": 4, "independent_replay_requests": oracle["distinct_deterministic_requests"]}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("action", choices=("run", "postprocess", "verify", "freeze", "verify-archive"))
    parser.add_argument("--output", type=Path, default=ROOT / "artifacts/generated/m06-fuzz-001")
    parser.add_argument("--measurements", type=Path, default=ROOT / "artifacts/generated/m06-measurements-001")
    parser.add_argument("--target-dir", type=Path, default=ROOT / "target/m06-fuzz-001")
    parser.add_argument("--cpu", type=int, default=10)
    parser.add_argument("--cpu-seconds", type=int, default=120)
    args = parser.parse_args()
    out, target, measured = args.output.resolve(), args.target_dir.resolve(), args.measurements.resolve()
    require((out.is_relative_to(ROOT / "artifacts/generated") or
             (args.action == "verify-archive" and out.is_relative_to(ROOT / "results/engine")))
            and out.name.startswith("m06"), "M06 output required")
    require(target.is_relative_to(ROOT / "target") and target.name.startswith("m06"), "new M06 target required")
    if args.action == "verify-archive":
        result = verify_archive(out)
    elif args.action == "run":
        result = prepare_and_run(out, measured, target, args.cpu, args.cpu_seconds)
    elif args.action == "postprocess":
        result = postprocess(out, target.parent / (target.name + "-coverage"))
    elif args.action == "verify":
        result = verify(out, finished=False)
    else:
        result = freeze(out)
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
