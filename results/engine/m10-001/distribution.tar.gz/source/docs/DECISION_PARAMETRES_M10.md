# M10 â€” dÃ©cision des paramÃ¨tres R1 et comparaison Ã  ML-KEM-1024

16 novembre 2026. PrÃ©enregistrement aprÃ¨s le protocole M10 du commit
`1105e7f`. Aucun paramÃ¨tre, domaine ou format Rust n'est modifiÃ© par ce
chantier. La dÃ©cision finale ci-dessous attend les sorties prÃ©vues,
y compris toute erreur ou expiration de dÃ©lai.

## Plan fixÃ© avant acquisition

ExÃ©cuter exactement **40 travaux neufs**, soit deux profils, deux jeux
finis d'Ã©chantillons, deux modÃ¨les de coÃ»t et cinq familles. R1 conserve
n=256, k=6, q=7681, CBD(3) ; ML-KEM-1024 a n=256, k=4, q=3329, CBD(2).
Les jeux sont respectivement m=1536/1792 et m=1024/1280. Le second est un
hybride idÃ©al distinct ; les chiffrÃ©s comprimÃ©s rÃ©els ne sont pas dÃ©clarÃ©s
fournir une ligne MLWE indÃ©pendante. Le passage au problÃ¨me LWE aplati
est un proxy d'estimation, pas une identitÃ© d'instances indÃ©pendantes.

L'estimateur est Ã©pinglÃ© au commit courant vÃ©rifiÃ© le 16 novembre :
`malb/lattice-estimator@7d59f866655362ea8eab803dbc833710c2bc362a`
(commit du 9 novembre 2026). Les 108 calculs M05 au commit f31b86fe restent
historiques ; ils ne sont pas comptÃ©s comme nouvelles Ã©valuations. Chaque
nouvelle paire ne compare que le mÃªme jeu, modÃ¨le, famille et convention.

Familles : uSVP/GSA ; BDD/GSA ; hybride primal avec MITM explicite,
Babai dÃ©sactivÃ© et GSA ; dual simple avec cible de solveur 0,99 ; dual
hybride MATZOV et son Î¼ interne0,5. Ces succÃ¨s ne sont pas interchangeables.
ModÃ¨les : MATZOV classique et sensibilitÃ© de rÃ©duction BCSS23 quantique,
en gardant les autres travaux de l'estimateur. Le second n'est pas un
comptage de portes d'une attaque quantique complÃ¨te.

Temps : 300 secondes murales par travail, quatre processus au plus,
affinitÃ©s choisies parmi CPU 0..5. Tous les 40 travaux sont demandÃ©s une
fois, sans remplacement d'une famille ou d'une expiration. Les entrÃ©es,
sorties, exceptions, stdout/stderr, durÃ©es et versions sont conservÃ©s.
Un dÃ©faut du contrÃ´leur pourra Ãªtre corrigÃ© seulement dans une reprise
explicitement reliÃ©e, avec les tentatives antÃ©rieures prÃ©servÃ©es.

L'optimisation de chaque famille reste sans plafond RAM, comme son API.
Le champ `mem`, lorsqu'il existe, garde son unitÃ© documentÃ©e en Ã©lÃ©ments
modulo q. Sa reprÃ©sentation dense en u16 fournit une sensibilitÃ© de
stockage dÃ©clarÃ©e pour des plafonds de 2^40, 2^60 et 2^80 octets ; elle
ne prouve pas le pic physique total. `N` reste un nombre de vecteurs et
n'est pas rebaptisÃ© RAM. Un optimum hors plafond n'est pas une preuve
d'absence d'autre attaque sous plafond. Aucun coÃ»t contraint ne sera
inventÃ© en filtrant simplement l'optimum non contraint.

## Sorties falsifiables et dÃ©cision

Le bilan annoncera les 20 paires attendues, les sorties manquantes, les
Ã©carts et la plage d'extrapolation de MATZOV au-delÃ  de Î²=1024. Il ne
rÃ©duira pas des contrats diffÃ©rents Ã  un minimum de sÃ©curitÃ© globale.
Une inversion dÃ©favorable R1/tÃ©moin dans un modÃ¨le retenu, ou un contrat
manquant, reste visible et bloque toute sÃ©lection finale automatique.

Le volet C03 calcule sÃ©parÃ©ment les recherches gÃ©nÃ©riques sur les graines
communes Ã  plusieurs clÃ©s, les messages sous une mÃªme clÃ© et les messages
liÃ©s Ã  des clÃ©s diffÃ©rentes. Les bornes exactes ou rationnelles sont
contrÃ´lÃ©es sur de petits espaces exhaustifs. Les requÃªtes quantiques
restent distinctes du coÃ»t des prÃ©dicats rÃ©versibles et de leur stockage.
Le nombre 256 dÃ©crit ici les espaces graines/messages et la sortie ; une
augmentation du rang n'augmente pas leur entropie.

Le volet correction rattache sans les recalculer les fractions certifiÃ©es
run-004 et leur transfert RO aux bruits semÃ©s, leur population et leur
quantification. Le seuil C05 historique 2^-174,8 est conservÃ©. Le rÃ©sultat
heuristique publiÃ© de ML-KEM-1024 ne devient pas un certificat identique,
et le taux honnÃªte ne traite pas une recherche adaptative d'Ã©checs.

La dÃ©cision C01â€“C06 sera soit la conservation motivÃ©e de R1 pour le
dÃ©veloppement, soit une proposition explicite de profil distinct. Les
obstacles de matrice semÃ©e, QROM, primitives concrÃ¨tes, queues du dual,
mÃ©moire bornÃ©e et nouvelles adaptations ne sont pas clos par un tableau
de coÃ»ts. Aucun nouveau profil ne sera substituÃ© au moteur Ã  la suite
d'un simple gain de rang ou d'un chiffre Core-SVP.

## Veille primaire consultÃ©e

La [documentation du mainteneur de l'estimateur](https://github.com/malb/lattice-estimator)
dÃ©crit son caractÃ¨re heuristique et recommande d'identifier le commit.
[Liâ€“Zheng2026/1048](https://eprint.iacr.org/2026/1048) traite la covariance
des scores ; [Bashiri2026/2565](https://eprint.iacr.org/2026/2565) amÃ©liore
des analyses duales prouvables. Leurs gains ne sont pas soustraits aux
coÃ»ts du panneau sans traduction de leur modÃ¨le.

[Kaiburr, version primaire du 3 novembre 2026](https://www.cryptojedi.org/papers/kaiburr-20261103.pdf),
d'Adhikari, Lyubashevsky et Schwabe, Ã©tudie des variantes de rang accru
avec une autre loi de bruit, q=3329 et retrait de la compression du
chiffrÃ©. Les auteurs publient [du code](https://github.com/cryptojedi/kaiburr),
des preuves de correction EasyCrypt et des rÃ©alisations C/Jasmin.
Cela interdit de prÃ©senter l'augmentation du rang comme une nouveautÃ©
suffisante. Ces profils, leurs cibles de correction et leurs conventions
Core-SVP sont distincts de R1 ; les fortes valeurs Core-SVP n'Ã©liminent
pas les limites dues aux primitives symÃ©triques inchangÃ©es.

## RÃ©sultats du panneau neuf

Les contrÃ´les de calcul ont Ã©tÃ© commis avant lancement au commit
`c37e9f7`. Les **40 travaux ont produit 40 coÃ»ts finis**, sans exception,
expiration ou remplacement. Le plus long a pris 95,293 secondes murales,
sous le plafond300 s. Ce temps mesure l'estimation, pas une rÃ©cupÃ©ration
de clÃ©. Sage 10.7/Python 3.12.15, NumPy 2.5.4 et SciPy 1.18.1 proviennent des
158 paquets Ã©pinglÃ©s ; leurs versions sont conservÃ©es. Le runtime tmpfs
absent a Ã©tÃ© rÃ©hydratÃ© depuis les archives locales vÃ©rifiÃ©es avant calcul.

Voici les valeurs `log2(rop)` du jeu key ; chaque ligne conserve son
contrat propre et ne reprÃ©sente pas un niveau global de sÃ©curitÃ©.

| ModÃ¨le | Famille | ML-KEM-1024 | R1 | DiffÃ©rence conditionnelle |
|---|---|---:|---:|---:|
| MATZOV classique | uSVP | 275,104 | 402,823 | +127,718 |
| MATZOV classique | BDD | 270,724 | 398,256 | +127,532 |
| MATZOV classique | Hybride primal MITM | 270,750 | 398,274 | +127,524 |
| MATZOV classique | Dual simple | 288,526 | 422,276 | +133,750 |
| MATZOV classique | Dual hybride MATZOV | 262,336 | 383,773 | +121,437 |
| SensibilitÃ© BCSS23 | uSVP | 224,006 | 340,110 | +116,104 |
| SensibilitÃ© BCSS23 | BDD | 224,884 | 341,120 | +116,236 |
| SensibilitÃ© BCSS23 | Hybride primal MITM | 224,884 | 341,120 | +116,236 |
| SensibilitÃ© BCSS23 | Dual simple | 231,695 | 350,362 | +118,667 |
| SensibilitÃ© BCSS23 | Dual hybride MATZOV | 214,789 | 325,958 | +111,169 |

Les **20 paires** des deux jeux finis sont favorables au proxy R1.
L'ajout de la ligne idÃ©ale ne change aucun des vingt coÃ»ts obtenus dans
cette exÃ©cution, sans Ã©tablir une Ã©quivalence des hypothÃ¨ses MLWE(6,6)
et(7,6). Les 24 sorties ayant une contrepartie M05 retrouvent exactement
leurs `log2(rop)` ; elles sont bien recalculÃ©es avec la nouvelle version,
mais ce constat n'est pas une nouvelle validation de l'heuristique.

Les huit appels d'hybride primal choisissent Î¶=0. Ils n'Ã©tablissent pas
qu'aucun hybride Ã  secret devinÃ© ne serait meilleur : l'optimisation de
Î¶ est locale, et sa gestion de d diffÃ¨re du wrapper BDD. Pour R1 classique,
le coÃ»t hybride est supÃ©rieur au BDD de 0,0181 unitÃ© logarithmique malgrÃ©
Î¶=0. Cet Ã©cart d'optimisation est conservÃ©. Aucun optimum exhaustif en
(Î¶,d,Î²) n'est prÃ©tendu. Dix sorties classiques R1 emploient des paramÃ¨tres
de rÃ©duction au-delÃ  de1024, hors la plage de calibration annoncÃ©e du
modÃ¨le fini MATZOV. Les rotations de la structure du module et les
rÃ©visions modernes de scores ne sont pas automatiquement absorbÃ©es par
l'API LWE aplatie.

## Ce que les ressources permettent de conclure

Le dual simple donne un champ mem documentÃ© en Ã©lÃ©ments modulo q.
Dans la convention dense u16 annoncÃ©e, son stockage au jeu key vaut :

| ModÃ¨le | log2 octets, ML-KEM-1024 | log2 octets, R1 |
|---|---:|---:|
| MATZOV classique | 196,310 | 290,690 |
| SensibilitÃ© BCSS23 | 198,402 | 295,070 |

Ces quatre points dÃ©passent chacun les trois plafonds de 2^40, 2^60 et 2^80
octets. Le champ ne valide pas tout le pic RAM d'une rÃ©duction, et les
autres familles ne fournissent pas un champ comparable contrÃ´lÃ© ici.
**Une comparaison rÃ©optimisÃ©e sous plafond RAM reste donc ouverte.**
Un contre-exemple exact du rapport donne une famille A avec points
(temps,mÃ©moire)=(1,100) et(3,1), puis B=(4,1). Filtrer seulement l'optimum
non contraint de A Ã  mÃ©moire1 masquerait son point faisable qui bat B.
Le panneau ne transforme pas une telle suppression en coÃ»t infini ou
en rÃ©sistance prouvÃ©e sous plafond.

## Limites symÃ©triques et cibles multiples

Les deux profils gardent des espaces graines/messages de 256 bits et des
sorties de 32 octets. Les recherches gÃ©nÃ©riques de taille 2^256 et leur
Ã©chelle de requÃªtes Grover 2^128 bornent ce qu'une augmentation du rang
peut promettre sur ces espaces ; les portes rÃ©versibles, la profondeur,
les prÃ©dicats et la mÃ©moire ne sont pas chiffrÃ©s par ces exposants.
Les rÃ©fÃ©rences primaires sont [Grover1996](https://arxiv.org/abs/quant-ph/9605043)
et [Zalka1999](https://arxiv.org/abs/quant-ph/9711070). Le rapport vÃ©rifie
son modÃ¨le fini, sans prÃ©tendre redÃ©montrer l'optimalitÃ© quantique gÃ©nÃ©rale.

Pour U cibles indÃ©pendantes et q candidats distincts testÃ©s dans un mÃªme
domaine de M points, la probabilitÃ© exacte est `1-(1-q/M)^U` ; le rapport
conserve un intervalle rationnel par inclusion-exclusion et borne d'union.
Cela dÃ©crit une recherche de graine commune Ã  plusieurs clÃ©s, ou des
messages sous une mÃªme clÃ©. Le stockage et le test cohÃ©rent d'appartenance
aux U cibles ne sont pas gratuits.

Pour des messages sous des clÃ©s diffÃ©rentes, le prÃ©dicat dÃ©pend de la
clÃ©. Avec q_i tests sous chaque clÃ©, le modÃ¨le indÃ©pendant donne
`1-prod_i(1-q_i/M) <= sum_i(q_i)/M`. Ã‰valuer un mÃªme candidat contre U clÃ©s
coÃ»te U prÃ©dicats ; le diviseur U n'est pas attribuÃ© gratuitement. Le
modÃ¨le quantique uniforme de paires (clÃ©,message) garde une densitÃ©1/M.
La rÃ©currence d'amplitudes de Grover est calculÃ©e exactement en fractions
sur petits espaces. Au total : 108 panneaux de recherche commune,
286 allocations de requÃªtes entre clÃ©s et 162 panneaux Grover exacts.
Les 15 panneaux Ã 256bits restent des modÃ¨les gÃ©nÃ©riques d'objectifs
dÃ©finis, sans borne globale IND-CCA.

## Correction, coÃ»t de format et dÃ©cision C01â€“C06

La fraction historique run-004 vÃ©rifie Ã  nouveau exactement
`delta^5 <= 2^-874`, soit le seuil 2^-174,8. Son affichage est environ
2^-310,086 dans le modÃ¨le CBD. Le transfert RO historique multiplie ce
majorant par `1-2^-256`, en moyenne sur les oracles/clÃ©s et pour le pire
message avec coins PKE frais. Cela ne certifie ni chaque clÃ© fixÃ©e ni
SHAKE concret. Le taux ML-KEM-1024 publiÃ© dans
[FIPS 203, tableau 1](https://nvlpubs.nist.gov/nistpubs/FIPS/NIST.FIPS.203.pdf)
est une estimation sous heuristique de fonctions alÃ©atoires ; le rapport
ne lui attribue pas le mÃªme statut que la fraction rationnelle R1.
Les erreurs adaptativement recherchÃ©es restent liÃ©es Ã  C01.

| Exigence | DÃ©cision M10 |
|---|---|
| C01 | Conserver le raccord exact en cours, sans clÃ´ture QROM/primitives concrÃ¨tes ni hÃ©ritage automatique de la preuve ML-KEM |
| C02 | Les 20 comparaisons prÃ©enregistrÃ©es passent le critÃ¨re relatif dans leurs modÃ¨les ; RAM bornÃ©e, structure, queues et optimalitÃ© globale empÃªchent encore un gel final |
| C03 | Aucune hausse d'entropie par le seul rang ; distinguer objectifs, cibles et coÃ»t des prÃ©dicats |
| C04/C05 | Conserver le tÃ©moin R1 et sa marge conditionnelle, sans transformer les essais du moteur en dÃ©monstration d'Ã©vÃ©nements rares |
| C06 | Conserver R1 pour le dÃ©veloppement, aucun nouveau profil sÃ©lectionnÃ©, aucune modification silencieuse du moteur |

Le coÃ»t de format est rÃ©el : clÃ© publique 2528 contre 1568 octets, chiffrÃ©
2656 contre1568, clÃ© privÃ©e dÃ©veloppÃ©e5088 contre 3168. Un Ã©change
comprenant une clÃ© et un chiffrÃ© prend 5184 contre 3136 octets, soit
**2048 octets supplÃ©mentaires (+65,306 %)**. Les 32 octets de secret partagÃ©
restent communs. Les tailles de rÃ©fÃ©rence sont celles de FIPS 203,
tableaux 2/3 ; les tailles R1 sont reconstruites de ses encodages.
Aucune nouvelle comparaison de performances entre rÃ©alisations des deux
KEM n'a Ã©tÃ© exÃ©cutÃ©e par ce chantier ; les gains M09 ne sont pas multipliÃ©s
aux chiffres d'anciens benchmarks pour en inventer une.

La conservation de R1 est une dÃ©cision de recherche motivÃ©e par les
comparaisons et la correction Ã©tudiÃ©e. Elle ne constitue pas une sÃ©lection
cryptographique finale ou une supÃ©rioritÃ© gÃ©nÃ©rale sur ML-KEM-1024.

## Conservation et rejeu

`results/security/m10-parameters-001` conserve 238 membres : plan,
40 entrÃ©es/sorties, flux et reÃ§us, contrÃ´leurs exÃ©cutÃ©s et d'analyse,
versions, provenance de l'estimateur et sources primaires rÃ©fÃ©rencÃ©es.
Les paquets Sage et les documents primaires complets restent dans le
cache local, sans redistribution externe dans cette capsule.

Deux incidents de posttraitement sont conservÃ©s : utilisation initiale
du manifeste run-004 de l'Ã©tude u-dependency Ã  la place du manifeste
sÃ©parÃ© du certificat ; puis diffÃ©rence de types tuples/listes au rejeu
JSON du petit contre-exemple mÃ©moire. Les corrections n'ont changÃ©
aucune des 40 sorties d'estimation, quantitÃ© ou conclusion numÃ©rique.
Le prÃ©contrÃ´le initial du runtime absent et sa rÃ©hydratation sont eux
aussi identifiÃ©s, sans crÃ©dit de calcul supplÃ©mentaire.

Le lecteur ne lance ni Sage ni tÃ©lÃ©chargement. Treize tests passent,
dont les refus de m infini, rÃ©sultat expirÃ© prÃ©sentÃ© comme fini, flux
altÃ©rÃ©, entrÃ©e historique rÃ©Ã©tiquetÃ©e et les contrÃ´les mathÃ©matiques finis.
Le rejeu sous `python -O` passe Ã©galement.

```powershell
.tools/research-venv/Scripts/python.exe -B research/m10_parameters_report.py verify
.tools/research-venv/Scripts/python.exe -B -m unittest discover -s research -p 'test_m10_parameters*.py' -v
```
