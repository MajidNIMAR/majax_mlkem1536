"""Root gate for long M10 qualification; no security finalization."""
from pathlib import Path
import json,sys
ROOT=Path(r'C:\Users\majax\Documents\Codex\NIST')
sys.path.insert(0,str(ROOT/'research'))
from run_m07 import read,require,save,sha,utc
from m10_measure import evaluate
from m10_secret_review import verify as review
from analyze_delivery_timing import analyze

candidate=ROOT/'artifacts/generated/m10-final-003'
source_sha=sha(candidate/'source.json')
require(source_sha=='67084be5ab1cde058661104b16e738138db7993dec001ac39625feb830b2810d','declared final source required')
measured=evaluate(candidate/'measurements')
require(measured==read(candidate/'measurements/evaluation.json') and measured['all_budgets_passed'] is True,
    'complete successful comparison required')
reviewed=review(ROOT/'artifacts/generated/m10-secret-review-003',ROOT/'artifacts/generated/m10-candidate-cli-003',
    ROOT/'artifacts/generated/m10-candidate-consumer-003')
require(reviewed['status']=='BOUNDED_REVIEW_PASS','four-image internal review required')
inputs=read(ROOT/'artifacts/generated/m10-secret-review-003/review.json')['inputs']
require(all(inputs[k]['source_manifest_sha256']==source_sha for k in ('cli','consumer')),'review concerns another source')
evidence=['source.json','validation.json','measurements/evaluation.json']
for action in ('build','validate','timing'):
    after=read(candidate/'execution'/action/'after.json')
    require(after['status']=='PASS' and after['failure'] is None
        and after['sources_and_controls_and_inputs_unchanged'] is True,'candidate execution not complete')
    evidence.extend(['execution/'+action+'/before.json','execution/'+action+'/after.json'])
for host in ('windows','linux'):
    rows=[json.loads(line) for line in (candidate/'timing'/host/'observations.jsonl').read_bytes().splitlines()]
    timed=analyze(rows)
    require(len(rows)==16000 and timed==read(candidate/'timing'/host/'analysis.json')
        and timed['threshold_crossings']==0,'timing signal requires investigation')
    evidence.extend([host+'/build.json','timing/'+host+'/analysis.json','timing/'+host+'/receipt.json'])
paths=[candidate/n for n in evidence]
paths.extend(ROOT/'artifacts/generated'/folder/'provenance.json' for folder in
    ('m10-secret-review-003','m10-candidate-cli-003','m10-candidate-consumer-003'))
paths.append(ROOT/'artifacts/generated/m10-secret-review-003/review.json')
output=ROOT/'artifacts/generated/m10-acceptance-001.json'
save(output,{'schema':'m10-engine-acceptance-v1','profile':'KEM1536-DEV-Q7681-R1','created_utc':utc(),
    'accepted_for_long_qualification':True,'source_manifest_sha256':source_sha,
    'campaign_plan_sha256':sha(ROOT/'research/m10-campaign-plan.json'),
    'checks':{'latency':True,'memory':True,'four_image_review':True,'finite_validation':True},
    'timing_diagnostic_threshold_crossings':0,
    'evidence_sha256':{p.relative_to(ROOT).as_posix():sha(p) for p in paths},
    'gate_controller_sha256':sha(Path(__file__)),'C01_closed':False,'final_parameter_selection':False,
    'external_review_performed':False,'whole_program_CT_or_erasure_proved':False})
print(json.dumps({'accepted_for_long_qualification':True,'source_manifest_sha256':source_sha,
    'marker':str(output),'bound_evidence_files':len(paths),'gate_sha256':sha(output)},indent=2))
