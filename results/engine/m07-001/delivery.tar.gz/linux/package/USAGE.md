# MAJAX R6 M07

Run bin/kem1536 dev-profile and bin/kem1536 dev-self-test (add .exe on Windows).
The self-test makes 16 fresh exchanges and checks 16 rejections without printing keys.
Research-only commands are disabled. This package contains the original reviewed delivered CLI;
the repeat is comparison evidence only. Memory, latency and timing diagnostics use their own
identified executables from the same candidate sources. See provenance.json and dependencies.json
for hashes, OS prerequisites, shared-cache repeat-build scope and Windows PE metadata limits.
Extract source.tar.gz and follow BUILD_M07.md for the Rust API/CLI sources.
Dependencies are not vendored; system libraries are prerequisites, not bundled components.
