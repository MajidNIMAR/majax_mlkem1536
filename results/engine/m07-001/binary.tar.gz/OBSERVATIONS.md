# M07 — revue binaire bornée des exécutables originaux

11 novembre 2026. La revue porte sur les quatre originaux compilés depuis
`m07-001/candidate-source`, et sur deux références M06 recompilées dans
`m07-001/baseline`. Aucun moteur, contrôle M06 ou résultat historique n'est
modifié. Les nouvelles copies de sources, binaires, reçus et listings
appartiennent exclusivement à ce dossier.

## Identification et méthode

La collecte a attendu l'existence du marqueur
`MEMORY_AND_LATENCY_ACCEPTED.json`, SHA-256
`d12f40553b29336684becc92362b13002b21b61893aea4b1da4a85f8f6301289`.
La copie du marqueur et les reçus de build sont conservés dans `inputs/`.
La revue ne reconstruit pas les exécutables et ne transforme pas leurs
octets pour les comparer.

| Cible | Type | SHA-256 exact |
| --- | --- | --- |
| Windows | candidat recherche | `66ad042a53ad4fd55b251b6fd091550efc70e0c7a5df861d3824235907b83156` |
| Windows | candidat livré | `c707186a5da83d5a5ed4523d713bdb204c95412818d8d18ba0a9ba9029105f33` |
| Linux | candidat recherche | `af546cdf1469959e6ff078f8e9fbc72efe717e5f28db10441fddda8d223b62f0` |
| Linux | candidat livré | `da097bdcd1340e6766791abdc1eb416e5fba4c1ebf8d2a775359a49a7e205014` |
| Windows | référence M06 recherche | `2f68e65fd193c0e5b272771ec74fe71fd9d23169c41ae990f875f159e724552a` |
| Linux | référence M06 recherche | `d83068e57ddc7e0da0145cd903976ed360a4d1afd163eec25b8086748f537115` |

Le candidat a `dev_kem.rs` SHA-256
`3b7594bf96b6dcf3a52001582f8ab832da774ed059db66999e0e5091c8c8d48b`.
La référence a `dev_kem.rs` SHA-256
`eb7635eedc73c3db93d7baa81a86817157969a82890f797acfb3694a767e0262`.
Tous deux conservent `engine_poly.rs`
`ffe7b50dfebfe8d9998296672bd1973a8376a02cb06f2338418e27f23a392ac2`
et `secret_box.rs`
`08d6ba7accadb46dc66b780a396dc418950641b29a91d365e12537001c40d28e`.
Le manifeste source candidat est
`51d33b0ac2f7a5444bee3c3a4d4d1567c3ba5dad7ff2b041358356eeb37ff76b` ;
celui de référence est
`268c03a1b3e1acbf427373bdf83076eef8990293cc79afb564a8dcbbca4f90c5`.

Les quatre audits sous `audit/` et les deux sous `audit-reference/`
conservent leurs binaires compressés, désassemblages complets, en-têtes,
versions d'objdump et inventaires. Le vérificateur reproduit les inventaires
existants, puis examine les fonctions ciblées **par adresse**. Plusieurs
monomorphisations Windows partagent en effet le même nom démanglé : six
`Polynomial::fill_with` et plusieurs `SecretBox::drop`. La première garde
a refusé de les confondre ; la collecte a ensuite repris avec leurs
identifiants distincts. Les compteurs physiques par adresses sont séparés
de l'inventaire historique indexé par nom. Les listings bruts ne changent pas.

## Balayage des formats et imports

À la source, `validate_vector_encoding` décode six lignes de 416 octets
dans un propriétaire réutilisé de 512 octets. Le masque de non-canonicalité
est accumulé avant la décision. `decode_polynomial_into` remplit les 256
coefficients ; les valeurs d'entrée sur 13 bits sont inférieures à 2q,
condition de la correction unique. Les imports gardent l'ordre longueur,
vecteur secret, vecteur public intégré, puis hash public. La suppression
du `Box` public temporaire dans l'import privé ne change pas ce contrat.

| Candidat | Import public | Import privé | Validation / décodeur retenus |
| --- | --- | --- | --- |
| Windows recherche | `0x140057440` | `0x140057290` | LLVM validate `0x140058890`, fill `0x14005b4e0` |
| Windows livré | `0x14004fea0` | `0x14004fcf0` | validate `0x1400512e0`, fill `0x140056cd0` |
| Linux recherche | intégré à `hardening::formats` | `0x2a4e60` | LLVM validate `0x2a62b0`, fill `0x2a8770` |
| Linux livré | non retenu | non retenu | décodeur PKE fill `0x2bacb0` ; aucune forme machine d'import revendiquée |

Dans les trois validations retenues, les six appels de décodage sont
inconditionnels. Leurs entrées sont les six offsets 0, 0x1a0, 0x340,
0x4e0, 0x680 et 0x820. Le décodeur parcourt 13j jusqu'à 0xd00, soit 256
coefficients, et écrit deux octets par coefficient dans la destination
reçue. La comparaison de réduction à q utilise une sélection conditionnelle
sans saut de rejet. Les contrôles de bornes observés concernent les indices
et la longueur de ligne fixe, pas une décision anticipée sur le coefficient.
Les six masques sont combinés après le balayage et le wipe de `checked`.
Le vérificateur contrôle les six appels et l'absence de transfert de contrôle
avant le sixième ; la qualification des indices et destinations est humaine.

`checked` est couvert par huit écritures de 16 bits sur 32 tours, pas 16 :
`[rsp+0x40,rsp+0x23f]` sous Windows et
`[rsp+0x28,rsp+0x227]` sous Linux recherche. La reconnaissance ne transforme
pas les blocs d'unwind supplémentaires en preuve de tous leurs chemins.

Windows recherche DK appelle la validation de s à `0x1400572ad`, celle
de ek à `0x1400572c4`, calcule le hash à `0x1400572df` puis décide à
`0x140057369`. La copie privée de 5088 octets à `0x140057393` va directement
de l'entrée vers l'allocation. La copie publique de 2528 octets est à
`0x14005748a`. Le livré conserve le même ordre sur ses propres adresses.
Linux recherche intègre l'import public à `hardening::formats@0x2aa0f0` :
longueur à `0x2aa33c`, validation à `0x2aa34c`, puis allocation et copie à
`0x2aa392`. Ce site public est relu dans le listing intégral ; ses autres
fonctions de harnais ne sont pas assimilées à des opérations sur secrets.
L'absence des imports Linux livrés ne prouve pas leur forme machine.

## Propriétaires PKE identifiés

Les adresses suivantes sont des débuts relatifs au `%rsp` stable de la
fonction correspondante. Tous les objets font 512 octets, sauf chaque
tableau NTT de six polynômes, qui fait 3072 octets. Les identités sont
établies par les arguments de forward, multiplication et inverse, et non
par l'ordre des initialisations.

| Fonction / owner | Windows recherche | Windows livré | Linux recherche | Linux livré |
| --- | ---: | ---: | ---: | ---: |
| KG coefficient | `0x80` | `0xcc0` | `0x58` | `0xa0` |
| KG transformed_s[6] | `0x480` | `0xc0` | `0x658` | `0x2a0` |
| KG product | `0x280` | `0xec0` | `0x458` | `0x10a8` |
| KG matrix_entry | `0x1080` | `0x10c0` | `0x1258` | `0x12a8` |
| KG sum | `0x1280` | `0x12c0` | `0x258` | `0xea8` |
| Encrypt coefficient | `0x50` | `0x50` | `0x38` | `0x38` |
| Encrypt transformed_r[6] | `0xa50` | `0xa50` | `0xa38` | `0xa38` |
| Encrypt product | `0x250` | `0x250` | `0x238` | `0x238` |
| Encrypt matrix_entry | `0x850` | `0x850` | `0x838` | `0x838` |
| Encrypt sum | `0x650` | `0x650` | `0x438` | `0x438` |
| Decrypt secret puis inverse | `0x70` | `0x770` | `0x48` | `0x748` |
| Decrypt value | `0x870` | `0x970` | `0xa48` | `0x948` |
| Decrypt v | `0x270` | `0x370` | `0x248` | `0x148` |
| Decrypt left | `0x470` | `0x570` | `0x448` | `0x548` |
| Decrypt right | `0xa70` | `0x170` | `0x648` | `0x348` |
| Decrypt sum | `0x670` | `0xb70` | `0x848` | `0xb48` |

Dans la recherche, les fonctions sont `keygen_internal`, le
`pke_encrypt_into` nommé LLVM et `pke_decrypt`. Dans le livré, KG est intégré
à `keygen` et Decrypt à `decapsulate`. Les JSON associent ces owners à
leurs fonctions exactes, leurs intervalles et les boucles reconnues.
Ils exigent la couverture complète de chaque intervalle ciblé, y compris
les six morceaux contigus des tableaux NTT. Ces volumes de fonctions
différentes ne sont pas additionnés pour annoncer un pic mémoire.

Les wipes du déchiffrement de recherche utilisent RCX ; ceux du livré
utilisent RAX. Quatre préambules KG ont des rechargements indépendants
entre le seed du compteur et la boucle : Windows recherche
`mov 0x30(%rsp),%rdi`, Windows livré `mov 0xb0(%rsp),%r13` puis
`lea 0x48(%rsp),%rdi`, Linux recherche `mov 0x8(%rsp),%r14`, et Linux
livré `mov 0x10(%rsp),%r13`. Ils ne touchent ni le compteur, ni rsp,
ni les flags, ni le stockage effacé. Le reconnaisseur M07 les autorise
précisément et les conserve dans chaque boucle concernée. Le contrôle
M06 reste inchangé. Les autres instructions intercalées ne bénéficient
pas d'une exemption générale.

Les encodages de s_i écrivent directement dans l'allocation privée, avant
réutilisation du coefficient. Sous Windows livré, les instructions
`0x140052641…0x140052659` établissent la destination heap privée
`rsi+i*0x1a0`, puis le forward est à `0x140052823`. Sous Linux livré,
la destination privée est `rbx+i*0x1a0` et le forward à `0x29e3b3`.
Les sorties u_i utilisent seulement leur tranche de 416 octets.

Les clés privées et chiffrés retournés restent détenus par leurs owners
heap après le retour de l'API. Leur durée de vie ne s'arrête pas avec le
frame KeyGen ou Encrypt. La source `SecretBox`, inchangée et copiée ici,
demande leur effacement avant libération ; les instances Drop retenues
sont conservées par adresse dans les rapports. La présente couverture
de boucles PKE ne constitue pas une preuve de tous les chemins de
destruction heap, des bibliothèques d'allocation ou des entrées empruntées
à l'appelant.

Les phases coefficient r_i/u_i/v et product message/t_i/inverse/compression
réécrivent entièrement leurs propriétaires. Les valeurs comprimées sont
inférieures à 32 et restent canoniques pour le stockage Polynomial.
L'inverse de Decrypt réutilise l'ancien propriétaire `secret` après sa
dernière lecture comme ligne de clé. Exemples : Windows livré
`sum+0xb70 → secret+0x770` à `0x14004d8c9`, Linux livré
`sum+0xb48 → secret+0x748` à `0x299cee`.

Dans les quatre helpers `inverse_into`, la copie de 512 octets va
directement de la source NTT vers la destination coefficient empruntée,
puis cette même destination est transformée. Windows livré : memcpy
`0x140057280`, transformée `0x14005728f` ; Linux livré : memcpy `0x2bb08f`,
transformée `0x2bb09f`. Aucun retour temporaire de Polynomial secret rempli
n'est identifié sur ces chemins. Les sauvegardes SIMD de l'ABI, les
registres, les spills et les corps système de memcpy ne sont pas couverts
par cette trace courte.

Decaps conserve la réencapsulation et la comparaison des 2656 octets,
le calcul J et la sélection conditionnelle. Dans le Linux livré, le
stockage `sum+0xb48` est réutilisé pour cp après le déchiffrement ; son
effacement propre de 2656 octets est visible à `0x29a780` (huit écritures
octet par tour, pas 8, compteur 7 à 2655). Cette observation ne prouve pas
l'effacement de toutes les copies du message ou du secret sélectionné.

## Spills de décodage : limite concrète et comparaison M06

Le wipe du propriétaire ne couvre pas le cadre du décodeur appelé. Une
observation négative est conservée : des bits du coefficient **encodé
avant réduction**, et non des indices ou le masque final, sont placés
dans des slots DWORD du callee sans effacement explicite à son épilogue.
Les six témoins d'instructions sont liés aux corps et binaires exacts
dans `spill-witnesses.json`. Le vérificateur contrôle leurs empreintes et
leurs instructions ; la qualification de provenance ci-dessous résulte
de la lecture des BT/SETB/SHL et des relectures, pas d'un solveur général.

| Binaire | Décodeur | Stores examinés |
| --- | --- | --- |
| M07 Windows recherche | `0x14005b4e0` | bit 11 dans `[rsp+0x24]`, store `0x14005b61e`, relu `0x14005b742` |
| M07 Windows livré | `0x140056cd0` | bit 11 dans `[rsp+0x24]`, store `0x140056e0e` |
| M07 Linux recherche | `0x2a8770` | bit 11 `[rsp+4]` à `0x2a88b0`, bit 10 `[rsp]` à `0x2a88d4` |
| M07 Linux livré | `0x2bacb0` | mêmes bits à `0x2badf0` et `0x2bae14` |
| M06 Windows recherche | `0x14005d8e0` | bit 11 `[rsp+0x34]` à `0x14005d988`, relu `0x14005db19` ; bits 8–10 également visibles |
| M06 Linux recherche | `0x2ab320` | bits 11/10 à `0x2ab3c1`/`0x2ab3e5` ; bits 8–9 également visibles |

Le store du bit 11 porte la valeur 0 ou 2^11. Dans la validation M07,
après le dernier coefficient, il provient de la position 255 de la ligne
5 ; la lecture ne révèle donc pas un polynôme complet. Avec C=rsp stable
de l'import privé candidat Windows, V=C−0x280 pour validate et
F=V−0xa0 pour le décodeur, le slot F+0x24 vaut **C−0x2fc**.
Sur s-invalid, `0x1400572b4 → 0x1400573a6 → 0x1400573b7` ne contient
aucun nouvel appel ni écriture qui le couvre : le bit subsiste jusqu'au
retour d'import observé. Le wipe checked du frame V ne le couvre pas.

Sous Linux recherche M07, V=C−0x260 et F=V−0x70. Les slots sont
**C−0x2cc** (bit 11) et **C−0x2d0** (bit 10). Le chemin s-invalid
`0x2a4e84/86 → 0x2a4f79 → 0x2a4f7c → 0x2a4f7e → 0x2a4f80…8c`
retourne sans nouvel appel ni écriture les couvrant. Le masque de première
ligne peut aussi occuper un slot auxiliaire hors checked : cela confirme
la limite d'une preuve reposant seulement sur le propriétaire.

Sur **s valide**, le second validate de ek part du même C sur les deux OS
(`0x1400572c4` Windows, `0x2a4e96` Linux). Il réutilise les mêmes V/F et
réécrit ces slots avec les coefficients **publics** de ek, avant la décision
de canonicalité de ek, le hash et le succès. Cela couvre aussi les erreurs
ultérieures ek-invalid/hash-invalid. Les appels système suivants ne sont
pas intégralement suivis ; aucune garantie universelle sur le contenu final
de toutes les copies n'est tirée de cette réécriture.

La référence Windows M06 fait déjà BT sur le bit 11 à `0x14005d977`,
SETB/SHL11, store `[rsp+0x34]`, puis retour sans wipe de ce slot. Sur
s-invalid, DK `0x140058250` appelle decode `0x140058292`, décide à
`0x140058299`, exécute les six wipes de ses propriétaires appelants puis
retourne à `0x1400584ba`. Le spill est à C−0x11c ; les wipes positifs
`[C+0x48,C+0xc47]` ne le recouvrent pas. La référence Linux montre aussi
des spills des mêmes bits dans son décodeur, sans effacement explicite.

La présence du spill de coefficient et la limite du chemin d'import privé
invalide sont donc **préexistantes sur les chemins M06 comparés**, et non
introduites par cette modification M07. Cela n'est pas une comparaison
exhaustive du nombre ou de la taille de toutes les copies. Aucune fuite
matérielle ou exploitation n'est démontrée. Les notes ne donnent pas un
avis d'effacement général. Dans le Linux livré, qui ne retient pas les
imports, Decaps décode s puis u dans le même frame callee ; le second
décodage réécrit ces slots par le chiffré public, avant les suites du calcul.

## Conclusion bornée et reproduction

Aucun défaut fonctionnel matériel ni owner ciblé privé d'écritures nulles
n'a été identifié sur les chemins examinés. Le spill historique reste
une limitation explicite. Les divisions sont absentes des instances
crypto ciblées, y compris les monomorphisations ; les autres fonctions,
oracles système, allocations, comparaisons et transferts indirects ne
reçoivent pas une preuve globale de temps constant.

Le reconnaisseur vérifie des boucles littérales avant le premier ret
textuel et une trace ABI courte. La couverture des intervalles ne prouve
pas que toute branche de contrôle les atteint, ni que tous les registres,
spills, temporaires de 32/64 octets ou chemins d'arrêt sont effacés. La
remise à zéro fonctionnelle de `clear` et les réécritures normales ne sont
pas assimilées à une preuve d'effacement volatile de toutes les copies.

Les sources et listings ont fait l'objet de contre-lectures séparées.
Les tests du nouvel outil couvrent la barrière des mesures, le scellement
après prévalidation, les noms LLVM et adresses distinctes, et la liaison
des compteurs et écritures des wipes. Le reçu scellé conserve les outils.
Son rejeu ne lance aucun nouvel objdump :

```text
python -B research/review_m07_binary.py verify --output artifacts/generated/m07-binary-001
```

La revue ne constitue ni un audit extérieur, ni une preuve IND-CCA,
ni une preuve générale de temps constant ou d'effacement. Elle n'attribue
aucun budget de fuzzing ou résultat de performance historique à M07.
