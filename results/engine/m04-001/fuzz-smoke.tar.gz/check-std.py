from pathlib import Path
import gzip, hashlib, json, subprocess
root=Path(__file__).resolve().parents[3]
std=sorted((root/'target/m04-fuzz/x86_64-unknown-linux-gnu/release/deps').glob('libstd-*.rlib'))
assert len(std)==1,std
nm=root/'.tools/linux-rustup/toolchains/1.91.1-x86_64-unknown-linux-gnu/lib/rustlib/x86_64-unknown-linux-gnu/bin/llvm-nm'
raw=subprocess.check_output([str(nm),'--undefined-only',str(std[0])],stderr=subprocess.STDOUT)
lines=raw.decode(errors='replace').splitlines()
refs=[line.strip() for line in lines if '__asan_' in line]
assert any('report_' in line for line in refs),'no std ASan access-report references'
out=Path(__file__).resolve().parent
with (out/'rebuilt-std-undefined-symbols.txt.gz').open('xb') as stream:
    with gzip.GzipFile(fileobj=stream,mode='wb') as zipped:zipped.write(raw)
result={'std_rlib':str(std[0].relative_to(root)),'std_sha256':hashlib.sha256(std[0].read_bytes()).hexdigest(),
        'undefined_ASan_reference_lines':len(refs),'distinct_ASan_symbols':sorted(set(refs)),
        'meaning':'ASan access instrumentation references exist in the rebuilt std rlib; not complete coverage of all assembly/OS/system libraries'}
with (out/'rebuilt-std-instrumentation.json').open('x',encoding='utf-8') as stream:json.dump(result,stream,indent=2);stream.write('\n')
print(json.dumps(result,indent=2))
