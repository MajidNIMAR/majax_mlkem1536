# M09 scalar transform: targeted correction review

The previous table-vectorized variant is rejected. Four new images retain a scalar transform without SIMD saves; the six explicit frame stores are traced to public pointers/counters/twiddle. This removes the specific XMM8-save mechanism. The message owner has 32 literal normal-return byte wipes in each image.

This bounded internal review does not prove whole-program constant time, complete PKE erasure or erasure of all ABI/register/caller copies. Supply the two retained CLI/consumer collections to the copied reader's verify action. No compiler, binary or machine tool executes during verify.
