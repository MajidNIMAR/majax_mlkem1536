# M09 — variante scalaire après rejet de la vectorisation

16 novembre 2026. Addendum fixé avant mutation du candidat scalaire.

La variante à tables de `m09-poly-001` et le moteur typé
`m09-final-001` ne sont pas promus. La revue Windows constate une nouvelle
copie de coefficient par sauvegarde ABI XMM de transform. Leurs données
et paquets restent figés avec la décision négative.

Un seul prototype correctif est autorisé ici : conserver les 255 twiddles
publics par direction et placer `std::hint::black_box(twiddle)` sur la
valeur publique de chaque butterfly, afin d'empêcher l'auto-vectorisation
observée. Aucun domaine, format, paramètre, compte de transformées ou
opération mathématique ne change. Le candidat reprend les contrats et
le cycle de vie typés du moteur final-001. La barrière n'est ni une
preuve universelle de temps constant ni une garantie LLVM à elle seule.

Avant compilation globale, construire un micro-consommateur Windows et
Linux et inspecter transform : aucune sauvegarde XMM callee-save nouvelle,
aucune nouvelle sauvegarde de coefficient secret hors propriétaire,
aucune division entière. La barrière peut stocker le twiddle public sur
la pile ; sa provenance doit être conservée dans la revue.

La référence reste le snapshot M08 immuable et ses binaires micro/KEM
de `m09-poly-001`. Le candidat aura un nouveau snapshot dans
`artifacts/generated/m09-poly-002`. Le manifeste de préenregistrement
lie ce texte et les captures avant mutation. Cibles séparées sous
`target/m09-poly-002`; Rust1.91.1 et caches/outils partagés déclarés.

Comparaison finie sur CPU10, quatre séries AB/BA, 250 observations KEM
par opération/version/série et 50 échauffements. Micro : 500 observations
par opération/version/série, 32 appels par observation, 50 échauffements.
Toutes les observations sont conservées, sans exclusion ni répétition
sélectionnée. L'hôte n'est pas isolé. Le témoin multiply_add est publié
comme diagnostic, sans prétendre le budget de la première campagne satisfait.

Budgets préalables : chaque opération KEM médiane ≤1,05 et p95 ≤1,20 fois
la référence ; gain médian ≥5 % sur au moins une opération KEM par OS.
Les micro-latences sont exploratoires, sans condition supplémentaire.
La qualification globale ultérieure conserve la limite mémoire par cas
de +1024 octets de maximum observé, allocations identiques et tables
publiques ≤1024 octets. Elle aura ses propres images et preuves ; cette
étude préalable ne vaut pas livraison ou fermeture du durcissement.
