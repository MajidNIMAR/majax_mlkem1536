# MAJAX R6 M09 — compact sources

Rust 1.91.1, native C linker and the platform Rust target are required.
Dependencies are locked, not vendored; a new computer needs registry access or matching Cargo caches.

```sh
cargo +1.91.1 build --release --locked -p kem1536-cli --bin kem1536
./target/release/kem1536 dev-self-test
```

Windows uses kem1536.exe and x86_64-pc-windows-gnu with the provided .cargo/config.toml.
The compact archive contains the captured compilation closure plus selected documents;
it does not contain all historical research evidence or a vendored toolchain.
