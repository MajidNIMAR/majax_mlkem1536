# MAJAX R6 M09

Run bin/kem1536 dev-profile or bin/kem1536 dev-self-test (.exe on Windows).
Self-test performs 16 fresh exchanges and 16 rejection checks without printing keys.
Research commands are disabled. This package ships the original M09 CLI, not its repeat build.
The same-host repeat shares tools, dependency caches and source path; it is not reproduction by a third party.
See dependencies.json for resolved normal/build graphs and system prerequisites. These graphs do not attribute linker symbols.
System DLLs/libc are prerequisites, not bundled libraries. Sources and license texts are included.
The R1 rank-six KEM is experimental, outside the NIST ML-KEM parameter sets; no external audit or universal CT/erasure proof is claimed.
