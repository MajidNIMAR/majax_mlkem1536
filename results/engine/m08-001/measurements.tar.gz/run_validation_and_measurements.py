import sys,json,subprocess,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3]
sys.path.insert(0,str(ROOT/'research'))
from run_m08 import binary,execute,save,sha,utc,read,probe,latency
from capture_m07_timing import affinity
from analyze_delivery_timing import analyze
out=Path(__file__).resolve().parent
for host in ['windows','linux']:
 probe(out,'candidate',host,20)
 exe=binary(out,'candidate',host,'consumer');folder=out/'candidate'/host/'validation';folder.mkdir()
 for mode in ['smoke','fixture-digests','exhaustive']:
  raw,command,errors,code=execute(exe,host,[mode]);(folder/(mode+'.stdout')).write_bytes(raw);(folder/(mode+'.stderr')).write_bytes(errors);assert code==0,(host,mode,code)
  data=json.loads(raw);assert data.get('secrets_printed',False) is False
  if mode=='exhaustive':assert data['total_cases']==88576 and data['all_expected_statuses_and_accepted_encodings_match']
  if mode=='fixture-digests':assert data==read(out/'baseline'/host/'validation/fixture-digests.json')['data']
  save(folder/(mode+'.json'),{'command':command,'binary_sha256':sha(exe),'exit_code':code,'executed_utc':utc(),'stdout_sha256':sha(folder/(mode+'.stdout')),'stderr_sha256':sha(folder/(mode+'.stderr')),'data':data})
  print(host,mode,'PASS',data.get('total_cases',''),flush=True)
command=[sys.executable,'-B',str(ROOT/'research/validate_m04_engine.py'),'--windows',str(binary(out,'candidate','windows','research')),'--linux',str(binary(out,'candidate','linux','research')),'--output',str(out/'regression')]
with (out/'regression-acquisition.log').open('xb') as log:subprocess.run(command,cwd=ROOT,stdout=log,stderr=subprocess.STDOUT,check=True)
print('Full Windows/Linux corpus regression passed',flush=True)
for host in ['windows','linux']:
 for kind in ['latency','consumer']:latency(out,host,kind,1000,100,5,10)
timing=out/'timing';timing.mkdir();results={}
for host in ['windows','linux']:
 folder=timing/host;folder.mkdir();exe=binary(out,'candidate',host,'timing')
 with affinity(10):raw,command,errors,code=execute(exe,host,['delivery-timing'],10 if host=='linux' else None)
 (folder/'observations.jsonl').write_bytes(raw);(folder/'runtime.stderr').write_bytes(errors);assert code==0
 report=analyze(json.loads(line) for line in raw.splitlines());save(folder/'analysis.json',report)
 results[host]={'binary_sha256':sha(exe),'command':command,'raw_sha256':sha(folder/'observations.jsonl'),'analysis_sha256':sha(folder/'analysis.json'),'maximum_absolute_t':report['maximum_absolute_t'],'threshold_crossings':report['threshold_crossings']}
 print('timing',host,report['maximum_absolute_t'],report['threshold_crossings'],flush=True)
save(timing/'capture.json',{'created_utc':utc(),'source_manifest_sha256':sha(out/'candidate-source.json'),'controller_sha256':sha(Path(__file__)),'hosts':results,'observations':32000,'CPU':10,'constant_time_proved':False})
print('M08 quantitative/functional phase finished',flush=True)
