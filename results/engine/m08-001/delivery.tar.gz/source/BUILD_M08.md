# MAJAX R6 M08 compact source

Use Rust 1.91.1 and an appropriate native C linker. From this root:

```sh
cargo +1.91.1 build --locked --release -p kem1536-cli --bin kem1536
./target/release/kem1536 dev-self-test
```

On Windows use kem1536.exe. Cargo.lock pins dependencies; they are not vendored.
A new machine needs registry access or matching Cargo caches. The Windows GNU
target uses the included .cargo/config.toml and Rust self-contained linking.
The source contains the measured compilation closure and selected API/specification
guides, not all historical research archives or local tools. Research-only
commands are disabled in this default CLI. See the accompanying provenance
for the exact original delivered executable and same-host repeat build.
