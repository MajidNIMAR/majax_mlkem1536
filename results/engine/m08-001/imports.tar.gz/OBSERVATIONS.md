# M08 — revue bornée des imports conservés en configuration normale

11 novembre 2026. Cette revue examine les quatre exécutables consommateurs
effectivement construits : référence M07 et candidat M08 sous Windows GNU
x86-64 et Linux x86-64. Elle porte sur les imports de la bibliothèque avec
fonctionnalités par défaut, leurs validateurs et retours normaux d'erreur.
Elle ne transfère pas les conclusions d'une ancienne empreinte vers une autre.

## Identification et provenance

La collecte a attendu le marqueur `MEMORY_AND_LATENCY_ACCEPTED.json`, SHA-256
`034557b8c1f76c9de590f3a3ef6168f9846d4112dcc43cf20c2ed21af230f9f8`.
Ses octets, les manifestes des deux sources et les quatre reçus de construction
sont copiés sous `inputs/`. Les six sources ciblées de chaque version sont
conservées sous `source/`. La collecte a revérifié l'intégralité des inventaires
de compilation avant tout objdump ; le rejeu autonome contrôle les copies
ciblées et les liaisons aux manifestes, sans prétendre reconstruire le compilateur.

| Version et hôte | SHA-256 du consommateur original |
|---|---|
| M07 Windows | `485724f2dde31a02cb8ea1a569102150880c85d4742022c05500ef1a08f4b5c1` |
| M07 Linux | `018560a0d917b311f4b729f51dd07cfba53dd5262bbe66d98b6dd39935b5b06c` |
| M08 Windows | `2c0c58d494823f2d3d03ddac95e8e651799c881fcaaec9034572665427ad5e70` |
| M08 Linux | `69ad82bdb58981861e29e95f1ddee82aabce6240f605491f88e687ed69be069e` |

Le cœur M07 est `dev_kem.rs`
`3b7594bf96b6dcf3a52001582f8ab832da774ed059db66999e0e5091c8c8d48b` ;
le candidat est
`b39c2fdfcdd7c22634162a2c451213a6c4309b27524a82069f37903653e12334`.
L'arithmétique, le stockage secret et le consommateur sont identiques entre
les deux captures. Les recettes déclarent Rust 1.91.1, sans métadonnées de
pile et sans demande `research-vectors` pour ces consommateurs.

Chaque dossier `audit/<version>-<hôte>` conserve le binaire compressé,
la désassemblage complet, les en-têtes, les relocations ELF lorsqu'applicables,
la version objdump et l'inventaire physique des fonctions. Les identifiants
comprennent l'adresse : des monomorphisations peuvent partager un même nom.
Les appels ELF des wrappers sont reliés aux fonctions par les relocations
`R_X86_64_RELATIVE`, sans supposer qu'un appel indirect pointe vers la bonne API.

## API et ordre des contrôles

Les wrappers `import_public_probe` et `import_private_probe` conservent les
appels des API ordinaires. Ils empruntent des entrées et stockent leur pointeur
et longueur pour `black_box` ; ils ne recopient pas leurs octets en pile.
Ils retournent le vrai `Result`, dont la validation et la destruction sont
effectuées hors de la fenêtre de latence par le consommateur.

| Image | Import privé | Validateur | Wrapper privé |
|---|---:|---:|---:|
| M07 Windows | `0x1400288f0` | `0x140029ee0` | `0x140002b60` |
| M08 Windows | `0x1400288f0` | `0x140029ee0` | `0x140002b60` |
| M07 Linux | `0x37ef0` | `0x39400` | `0x26100` |
| M08 Linux | `0x37eb0` | `0x393c0` | `0x260c0` |

Les appels privés vérifient d'abord la longueur `0x13e0` (5088), passent
le pointeur initial au validateur secret, puis le pointeur `entrée+0x9c0`
au validateur public intégré. Le hash public ne vient qu'après ces deux
validations. Les comparaisons de hash portent sur les 32 octets à
`entrée+0x13a0`, puis l'allocation/copie de 5088 octets n'a lieu qu'au succès.
Les imports publics vérifient leur longueur `0x9e0`, valident le préfixe
de 2496 octets et copient seulement ensuite la clé acceptée.

Le validateur renvoie AL=5 pour `Ok(())`, AL=1 pour l'erreur de canonicalité
dans ces formes observées. Ce sont les représentations internes observées,
distinctes des codes lisibles du consommateur. Après une erreur secrète,
le caller prend immédiatement la branche vers la construction de `Err`,
écrit seulement son tag et son code dans le résultat fourni par le caller,
puis restaure son cadre et retourne. Aucun autre appel n'intervient sur ce
trajet normal avant le retour de l'API et de son wrapper.

## Référence M07 : provenance effective des résidus

Le validateur M07 appelle six fois le décodeur `Polynomial::fill_with`
(`0x14002f760` Windows, `0x3c8a0` Linux), pour les offsets de lignes
0, `0x1a0`, `0x340`, `0x4e0`, `0x680`, `0x820`. Les six appels sont
inconditionnels avant la décision de canonicalité. Le décodeur parcourt
13j jusqu'à `0xd00`, soit 256 coefficients par ligne.

Dans les deux images, le bit 11 est lu dans l'octet contenant le bit
13j+11, extrait par BT/SETB, décalé de 11 puis écrit dans un DWORD de pile.
Linux stocke aussi le bit 10 par la même succession avant de l'ajouter
à l'assemblage du coefficient. Ces slots sont relus, sans être effacés.
Après la dernière itération, ils reflètent les bits du dernier coefficient
traité ; ils ne sont pas seulement des indices publics ou pointeurs.

On note **C** le RSP stable du caller privé après son prologue, **V** celui
du validateur et **F** celui du remplisseur après leurs prologues respectifs.
Les appels ajoutent chacun les huit octets de l'adresse de retour.

| Image | Cadres | Propriétaire effacé | Slots de bits hors propriétaire |
|---|---|---|---|
| M07 Windows | V=C−0x280 ; F=V−0xa0 | V+[0x40,0x23f] | bit11 : F+0x24=C−0x2fc, 4 octets |
| M07 Linux | V=C−0x260 ; F=V−0x70 | V+[0x28,0x227] | bit11 : F+4=C−0x2cc ; bit10 : F=C−0x2d0, 4 octets chacun |

Le wipe du propriétaire couvre 512 octets par 32 blocs de huit stores
16 bits. Il est disjoint de ces slots situés sous le cadre du validateur.
Les épilogues du décodeur et du validateur ne les recouvrent pas. Après le
retour secret invalide, le caller privé ne lance ni seconde validation ni
hash ni allocation : son retour n'ajoute donc pas un écrasement de ces slots.
Ces faits reproduisent la limite M07 sur les nouveaux consommateurs normaux,
avec leurs propres adresses et empreintes.

Lorsqu'une partie secrète est valide, la validation publique suivante emploie
les mêmes cadres et réécrit normalement ces slots avec des bits publics
avant une erreur publique/hash ou un succès. Le masque intermédiaire d'une
ligne peut aussi être stocké hors du propriétaire (Linux V+0x24). L'absence
de résidu de tous les prédicats n'est pas déduite du seul wipe de la Poly.

## Candidat M08 : balayage complet et écritures observées

Les validateurs M08 ne contiennent aucun appel. Chacun possède exactement
une branche conditionnelle : un retour de boucle commandé par le compteur
public RAX. Il est initialisé à zéro, progresse de 16 et s'arrête à 192.
Les deux LEA de tête calculent 3×RAX, puis 13×RAX. Chaque itération charge
une fois chacun des 208 offsets d'octets 0..207. Il y a donc douze itérations,
2496 octets lus et 192 groupes de huit coefficients, soit **1536 coefficients**.
Les adresses de lecture dépendent de la base et du compteur, pas des valeurs.

| Image | Tête de boucle | Incrément / borne | Unique branche | Réduction finale |
|---|---:|---|---:|---:|
| M08 Windows | `0x140029f60` | `0x14002ac19` / `0x14002ac1d` | `0x14002ac23` | `0x14002ac29` puis `pmovmskb@0x14002ac35` |
| M08 Linux | `0x393f0` | `0x3a05c` / `0x3a060` | `0x3a066` | `0x3a06c` puis `pmovmskb@0x3a078` |

Les vecteurs de prédicats sont réduits et le résultat formé **après** cette
boucle. Aucun saut de rejet anticipé fondé sur les données n'est présent
dans ces validateurs. Il n'y a pas de destination mémoire explicite dans
le corps de boucle ; toutes les données calculées restent dans les registres
pour ce calcul. Les cas d'erreur étudiés rejoignent ensuite le retour privé
décrit plus haut, sans appel supplémentaire.

Sous Linux, les seuls writes de pile du validateur sont les PUSH initiaux
de RBX/RBP, avant la première lecture d'entrée. Il n'a aucun opérande
mémoire explicite adressé par RSP/RBP dans son corps.

Sous Windows, le validateur réserve un cadre de sauvegarde ABI et écrit
les registres entrants XMM6..15 dans dix slots de 16 octets, **avant** toute
lecture d'entrée. Ces dix registres sont ensuite restaurés dans l'épilogue.
Ce sont les vingt accès explicites de pile du validateur. Aucun store de
valeur calculée à partir de l'entrée de ce validateur n'a été trouvé dans
sa boucle. Les PUSH généraux initiaux suivent la même distinction de provenance.

Ces sauvegardes ABI peuvent elles-mêmes contenir des données préexistantes
du caller ; elles ne constituent pas une zone universellement effacée.
La conclusion est la suppression des **copies ciblées de bits décodés
produites par ce chemin d'import**. Elle ne signifie pas que les anciens
offsets de pile sont activement mis à zéro, ni que la pile était vide avant
l'appel, ni que les registres de travail sont tous effacés après retour.

## Conclusion et limites

Les quatre consommateurs ont été revus et 124 témoins d'instructions
adressés sont conservés dans `witnesses.json`, avec les relations de cadres
et la dérivation du balayage. Le rejeu vérifie leurs instructions littérales
et tous les inventaires ; il ne refait pas l'analyse humaine de taint et
ne lance pas un nouvel objdump.

**Le candidat satisfait le constat ciblé dans ces images** : les copies de
bits de coefficients mises en pile par le décodage de validation M07 ne sont
plus produites sur les chemins d'import M08 examinés, sans rejet anticipé du
balayage. Les contrats d'ordre et de copie sont conservés. Les résultats
fonctionnels et quantitatifs distincts restent liés à leurs propres reçus.

Le PKE conserve son décodeur polynomial ; les autres chemins, copies,
registres, ABI, retours anormaux, bibliothèques système, contextes d'interruption
et futures compilations restent hors d'une preuve d'effacement universelle.
Cette revue n'établit pas de fuite exploitable pour M07, de temps constant
global, de sécurité IND-CCA globale, d'audit externe ou de certification.
L'import contrôle un encodage et un hash : il ne certifie pas la provenance
ou l'entropie de la clé de rejet empruntée au caller.
