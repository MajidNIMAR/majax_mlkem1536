# M09 — tables publiques de twiddles NTT

16 novembre 2026. Périmètre : optimisation interne compatible avec R1,
sur x86-64 Windows GNU et Ubuntu 22.04/WSL, Rust 1.91.1. M08 reste figé.

## Hypothèse et protocole avant candidat

La référence M08 calcule 1024 butterflies par transformée (8 × 128) et
recalcule le prochain twiddle public par un produit modulaire à chacune.
Une table publique de 255 puissances par direction suffit à toutes les
étapes. Les pré-calculer à la compilation retire ces 1024 produits,
sans changer les réductions des valeurs secrètes, les permutations,
les domaines du KEM ou les comptes 48/55/68 de transformations.

La capture indépendante `artifacts/generated/m09-poly-001/baseline-source`
précède toute mutation des trois fichiers du cœur. Ses 44 entrées incluent
la fermeture Rust, les inclusions extérieures et les deux probes M08.
Le manifeste SHA-256 est
`e49c9709e78be01539f908bb16fef5b3cf087dc0e5d3256049213fdb711ec691`.
Le candidat isolé conserve toutes ces entrées sauf engine_poly.rs ; le
candidat M09 final du programme principal sera qualifié séparément.

Avant modification, mesurer la référence sur les deux hôtes : forward,
inverse, multiply_add, et les quatre opérations KEM. Les micro-opérations
emploient uniquement des coefficients publics synthétiques, 32 appels par
observation, 500 observations et 50 échauffements par opération/série.
Les opérations KEM utilisent le harnais M07 inchangé, 250 observations et
50 échauffements. Comparaison : cinq séries AB/BA, ordre des opérations
tournant, CPU logique 10. Toutes les observations sont conservées ; aucune
exclusion. Les compilations peuvent partager les caches mais utilisent
des cibles distinctes. L'isolation globale de l'hôte n'est pas garantie.

Budgets fixés avant candidat : médiane forward et inverse ≤ 0,90 fois la
référence sur chaque hôte ; médiane de chacune des quatre opérations KEM
≤ 1,05 et p95 ≤ 1,20. multiply_add, non modifié, sert de témoin avec
médiane ≤ 1,10 et p95 ≤ 1,25. La taille des deux tables ne doit pas dépasser
1024 octets publics au total (255 × 2 × 2 = 1020 attendus). Aucun nouveau
buffer secret, aucune allocation et aucune récursion dans transform.
Les frames et .rodata des objets réels seront conservées ; une taille
statique n'est pas une borne du pic dynamique de pile. La qualification
globale M09 porte séparément sur la mémoire du KEM final.

La table est contrôlée indépendamment par exposants modulo q, en plus des
convolutions de l'oracle générique et des vecteurs historiques. Une forme
machine propre est requise : accès aux tables par seuls indices publics,
pas de division nouvellement introduite sur coefficients. Cette revue
bornée ne constitue pas une preuve universelle de temps constant,
d'effacement des registres/ABI, ni un audit externe.

## Résultats

Acquisition en cours. Une variante ne sera retenue qu'après la comparaison
brute complète ; une régression ou un échec reste conservé.
